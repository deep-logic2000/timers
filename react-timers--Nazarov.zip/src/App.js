import Header from "./components/Header/Header";
import ButtonsZone from "./components/TimerZone/ButtonsZone/ButtonsZone";
import LogsZone from "./components/TimerZone/LogsZone/LogsZone";

const App = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default App;
