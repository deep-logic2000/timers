import React from "react";

import TabPanel from "../NavTabs/NavTabs";

const Header = () => {
  return (
    <div>
      <TabPanel />
    </div>
  );
};

export default Header;
