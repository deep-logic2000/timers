import ButtonsZone from "./ButtonsZone/ButtonsZone";
import LogsZone from "./LogsZone/LogsZone";

export { ButtonsZone, LogsZone };